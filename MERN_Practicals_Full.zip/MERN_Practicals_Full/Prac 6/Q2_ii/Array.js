import React,{useState} from "react";

function Array(){
  const [users,setUsers]=useState(["User 1","User 2"]);

  function add(){
    setUsers([...users,"User "+(users.length+1)]);
  }

  function remove(i){
    setUsers(users.filter((x,index)=>index!=i));
  }

  return <div>
    <button onClick={add}>Add User</button>

    {users.map((x,i)=>
      <p>{x}
        <button onClick={()=>remove(i)}>Remove</button>
      </p>
    )}
  </div>
}

export default Array;
