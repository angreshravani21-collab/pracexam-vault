import Arraylist from "./Arraylist";

function App(){
  return <Arraylist/>
}

export default App;
