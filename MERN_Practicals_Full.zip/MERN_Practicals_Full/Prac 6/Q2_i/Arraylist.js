import React,{useState} from "react";

function Arraylist(){
  const [list,setList]=useState(["Earth","Jeff","Mew"]);

  function add(){
    setList([...list,document.getElementById("friend").value]);
  }

  return <div>
    <h1>List</h1>
    {list.map(x=><li>{x}</li>)}
    <input id="friend"/>
    <button onClick={add}>Add</button>
  </div>
}

export default Arraylist;
