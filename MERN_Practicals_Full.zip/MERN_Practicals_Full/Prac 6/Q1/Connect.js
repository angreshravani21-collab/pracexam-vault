const { MongoClient } = require("mongodb");

async function main() {
  const client = new MongoClient("mongodb://localhost:27017");

  try {
    await client.connect();
    console.log("Connected");

    const db = client.db("myDatabase");
    const collection = db.collection("myCollection");

    const data = [
      {name:"john",age:30},
      {name:"jane",age:25},
      {name:"joe",age:40}
    ];

    const result = await collection.insertMany(data);
    console.log(result.insertedCount + " documents inserted");

  } finally {
    await client.close();
  }
}

main();
