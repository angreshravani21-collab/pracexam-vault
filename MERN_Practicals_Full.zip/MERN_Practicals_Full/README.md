# MERN Practicals — Complete Question-wise Folder

This ZIP was organized from the uploaded `Bin (1).txt` practical sheet.

## Folder structure

Each practical is separated first, then each question is separated:

- `Prac 2/Q1` ... `Q4`
- `Prac 3/Q1` ... `Q4`
- `Prac 4/Q1` ... `Q2`
- `Prac 5/Q1` ... `Q2`
- `Prac 6/Q1`, `Q2_i`, `Q2_ii`
- `Prac 7/Q1` ... `Q3`
- `Prac 8/Q1` ... `Q3`
- `Prac 9/Q1` ... `Q2`
- `Prac 10/Q1` ... `Q4`

The original practical source files are kept with their practical names, such as `Classprops.js`, `App.js`, `Function_name.js`, `Read.js`, `Connect.js`, etc.

## IMPORTANT: You do NOT need node_modules in the ZIP

`node_modules` is intentionally not included because it is very large and should be installed by npm on the computer where you run the practical.

---

# A. How to install the ZIP in VS Code

### 1. Download the ZIP

Extract the ZIP somewhere easy to find, for example:

`Downloads\MERN_Practicals_Full`

### 2. Open it in VS Code

In VS Code:

**File → Open Folder → select `MERN_Practicals_Full`**

You will see `Prac 2`, `Prac 3`, ... `Prac 10`.

### 3. Make sure Node.js is installed

In the VS Code terminal:

```powershell
node -v
npm -v
```

Both should print version numbers.

---

# B. Running a React question

React questions contain a small Vite setup (`package.json`, `index.html`, `main.jsx`, `index.css`) in addition to the practical source files.

Example: Practical 2 Question 1 contains:

- `Classprops.js`
- `App.js`

plus the files required to run React.

### Steps

Open the question folder in the VS Code terminal.

For example:

```powershell
cd "Prac 2/Q1"
```

Then:

```powershell
npm install
```

Then:

```powershell
npm run dev
```

Open the local URL shown by Vite, normally:

`http://localhost:5173/`

### For Practical 10

Practical 10 uses React Router, so after `npm install`, run:

```powershell
npm install react-router-dom
npm run dev
```

---

# C. Running a Node.js question

Node questions contain their own `package.json` with CommonJS enabled so the supplied `require(...)` code can be run as `.js`.

Example:

```powershell
cd "Prac 3/Q1"
npm install
node Read.js
```

For a question with a different filename, use that filename.

Examples:

```powershell
node Async.js
node AsyncAwait.js
node Write.js
node pr4.js
node factorial.js
```

For a server question:

```powershell
node server.js
```

Then open the URL printed by the program.

---

# D. Practical 5 Question 2 — Express

Open:

```powershell
cd "Prac 5/Q2"
```

Install dependencies:

```powershell
npm install
```

Run:

```powershell
node users.js
```

The program listens on port 8080.

---

# E. Practical 6 Question 1 — MongoDB

This question needs a MongoDB server running locally.

Open:

```powershell
cd "Prac 6/Q1"
```

Install the Node MongoDB package:

```powershell
npm install
```

Then make sure MongoDB is running locally at:

`mongodb://localhost:27017`

Run:

```powershell
node Connect.js
```

The supplied program connects to `myDatabase`, uses `myCollection`, and inserts the three documents from the practical sheet.

---

# F. Stopping a running program

For a Vite server or Node server running in the terminal, press:

```text
Ctrl + C
```

---

# G. Important note about the source

The code files are based on the uploaded practical sheet. Supporting Vite files and small sample input files were added only where needed to make the supplied code runnable.

The source practical code itself was not intentionally rewritten or replaced with different solutions.
