const express = require("express");
const users = require("./users.json");

const app = express();

app.get("/api/v1/users", (req, res) => res.json(users));

app.get("/api/v1/users/:id", (req, res) => {
  let user = users.find(u => u.id === Number(req.params.id));
  res.json(user);
});

app.listen(8080, () => console.log("Server Running"));
