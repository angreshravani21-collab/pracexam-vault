const http = require("http");

http.createServer((req, res) => {
  if (req.url == "/hello")
    res.end("Hello World!");
  else if (req.url == "/about")
    res.end("This is the about page.");
  else
    res.end("Node.js Server!!");
}).listen(4000);

console.log("Server running at http://127.0.0.1:4000/");
