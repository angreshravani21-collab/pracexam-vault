import {useReducer} from "react";

function reducer(n,a){
  if(a=="add") return n+1;
  if(a=="sub") return n-1;
  return 0;
}

function App(){
  const [n,dispatch]=useReducer(reducer,0);

  return( <div>
    <h2>{n}</h2>
    <button onClick={()=>dispatch("add")}>Increment</button>
    <button onClick={()=>dispatch("sub")}>decrement</button>
    <button onClick={()=>dispatch("reset")}>reset</button>
  </div>);
}

export default App;
