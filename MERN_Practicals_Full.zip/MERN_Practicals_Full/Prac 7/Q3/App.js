import {useReducer} from "react";

function reducer(user,action){
  if(action=="login") return "John";
  return "";
}

function App(){
  const [user,dispatch]=useReducer(reducer,"");

  return( 
  <div>
    <h2>{user ? "Welcome, "+user : "Please Login"}</h2>
    <button onClick={()=>dispatch("login")}>Login</button>
    <button onClick={()=>dispatch("logout")}>Logout</button>
  </div>);
}

export default App;
