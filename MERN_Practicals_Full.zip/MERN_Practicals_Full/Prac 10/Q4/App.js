import {BrowserRouter,Routes,Route,Link,Outlet} from "react-router-dom";

function Products(){
  return <div>
    <h1>Products</h1>
    <Link to="electronics">Electronics</Link> |{" "}
    <Link to="clothing">Clothing</Link>
    <Outlet/>
  </div>;
}

function Electronics(){
  return <><h2>Electronics</h2><p>Mobile phones, laptops and other electronic items.</p></>;
}

function Clothing(){
  return <><h2>Clothing</h2><p>Shirts, jeans, jackets and other clothing items.</p></>;
}

function App(){
  return <BrowserRouter>
    <nav>
      <Link to="/">Home</Link> | <Link to="/products">Products</Link>
    </nav>

    <Routes>
      <Route path="/" element={<h1>Home</h1>}/>
      <Route path="/products" element={<Products/>}>
        <Route path="electronics" element={<Electronics/>}/>
        <Route path="clothing" element={<Clothing/>}/>
      </Route>
    </Routes>
  </BrowserRouter>;
}

export default App;
