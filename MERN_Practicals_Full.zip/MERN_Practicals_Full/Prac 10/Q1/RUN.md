# Run this question

Open this folder in VS Code.

In the VS Code terminal:

```powershell
npm install

For Practical 10, install the router dependency first:
  npm install react-router-dom
npm run dev
```

Then open the local URL printed by Vite (normally http://localhost:5173/).

This folder contains the practical code plus the small Vite files needed to run it.
