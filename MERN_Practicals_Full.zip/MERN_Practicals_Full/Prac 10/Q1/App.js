import {BrowserRouter,Routes,Route,Link} from "react-router-dom";

function Home(){
  return <><h1>Home Page</h1><p>Welcome to our website!</p></>;
}

function About(){
  return <><h1>About Page</h1><p>This is the about page.</p></>;
}

function Contact(){
  return <><h1>Contact Page</h1><p>Contact us at example@gmail.com</p></>;
}

function App(){
  return <BrowserRouter>
    <nav>
      <Link to="/">Home</Link> |{" "}
      <Link to="/about">About</Link> |{" "}
      <Link to="/contact">Contact</Link>
    </nav>

    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/about" element={<About/>}/>
      <Route path="/contact" element={<Contact/>}/>
    </Routes>
  </BrowserRouter>;
}

export default App;
