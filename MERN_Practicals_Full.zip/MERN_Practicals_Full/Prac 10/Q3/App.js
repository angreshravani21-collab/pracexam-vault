import {BrowserRouter,Routes,Route,Link} from "react-router-dom";

function Home(){return <h1>Home Page</h1>;}
function About(){return <h1>About Page</h1>;}
function Contact(){return <h1>Contact Page</h1>;}

function NotFound(){
  return <><h1>404 - Page Not Found</h1>
  <p>Sorry, the page you are looking for does not exist.</p></>;
}

function App(){
  return <BrowserRouter>
    <nav>
      <Link to="/">Home</Link> |{" "}
      <Link to="/about">About</Link> |{" "}
      <Link to="/contact">Contact</Link>
    </nav>

    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/about" element={<About/>}/>
      <Route path="/contact" element={<Contact/>}/>
      <Route path="*" element={<NotFound/>}/>
    </Routes>
  </BrowserRouter>;
}

export default App;
