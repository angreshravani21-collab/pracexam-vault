import React from "react";

class Unmount extends React.Component {
  state = { delete: false };

  render() {
    return <div>
      <h1>User List</h1>
      <button onClick={() => this.setState({delete:true})}>Delete Users</button>
      {!this.state.delete && <User />}
    </div>;
  }
}

class User extends React.Component {
  componentWillUnmount() {
    alert("delete user successfully!");
  }

  render() {
    return <div>
      <h3>Mulund College of Commerce (Autonomous) 2026-27</h3>
      <h3>UserName: dummy</h3>
      <h3>Email: dummy@gmail.com</h3>
    </div>;
  }
}

export default Unmount;
