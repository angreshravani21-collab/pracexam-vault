import './App.css';
import Header from './exam';

function App() {
  return <Header />;
}

export default App;
