import React from "react";

class Header extends React.Component {
  constructor() {
    super();
    this.state = { favcolor: "red" };
  }

  componentDidMount() {
    setTimeout(() => {
      this.setState({ favcolor: "blue" });
    }, 5000);
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    document.getElementById("div1").innerHTML =
      "Before update, favcolor was " + prevState.favcolor;
  }

  componentDidUpdate() {
    document.getElementById("div2").innerHTML =
      "The updated favcolor is " + this.state.favcolor;
  }

  render() {
    return (
      <section>
        <h2>This is Practical 9 Question 1 {this.state.favcolor}</h2>
        <div id="div1"></div>
        <div id="div2"></div>
      </section>
    );
  }
}

export default Header;
