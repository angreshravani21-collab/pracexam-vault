import React,{Component} from "react";

class Counter extends Component {
  state = {count:0};

  render() {
    return <div>
      <h1>{this.state.count}</h1>
      <button onClick={() => this.setState({count:this.state.count+1})}>
        INCREMENT
      </button>
    </div>;
  }
}

export default Counter;
