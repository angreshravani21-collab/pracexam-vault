import Counter from "./Classcounter";

function App() {
  return <Counter/>;
}

export default App;
