import React from "react";

function Child(props) {
  return <h2>{props.name} <br /> {props.age}</h2>;
}

function Parent(props) {
  return (
    <>
      <h1>Parent Class {props.address}</h1>
      <Child name="Parent Name" age="50" />
    </>
  );
}

export default Parent;
