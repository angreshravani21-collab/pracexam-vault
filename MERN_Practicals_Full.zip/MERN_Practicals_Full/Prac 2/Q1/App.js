import Parent from "./Classprops";

function App() {
  return <Parent address="qwerty" />;
}

export default App;
