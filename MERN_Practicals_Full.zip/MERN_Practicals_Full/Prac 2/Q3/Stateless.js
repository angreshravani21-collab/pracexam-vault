import {useState} from "react";

function Message() {
  const [msg,setMsg] = useState("Welcome Visitors");

  return <div>
    <h1>{msg}</h1>
    <button onClick={() => setMsg("Thank you for visiting!")}>CLICK HERE</button>
  </div>;
}

export default Message;
