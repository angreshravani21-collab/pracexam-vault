import Message from "./Stateless";

function App() {
  return <Message/>;
}

export default App;
