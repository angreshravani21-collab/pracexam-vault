import React from "react";

export function Car(props) {
  return <h2>I am a {props.name} !!!</h2>;
}

export function Product() {
  return <div>
    <h1>Product Details</h1>
    <Car name="Wagonr"/>
  </div>
}
