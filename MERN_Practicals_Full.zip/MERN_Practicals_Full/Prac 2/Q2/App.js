import {Car, Product} from "./Function_name";

function App() {
  return <div>
    <Car name="Brezza"/>
    <Product/>
  </div>
}

export default App;
