import {createContext,useContext} from "react";

const C=createContext();

function App(){
  return <C.Provider value={{name:"Rahul",dept:"IT",salary:50000}}>
    <C1/>
  </C.Provider>;
}

function C1(){
  return <><C2/><C4/></>;
}

function C2(){
  return <C3/>;
}

function C3(){
  let e=useContext(C);
  return <><h2>Component 3</h2><p>Name: {e.name}</p></>;
}

function C4(){
  return <C5/>;
}

function C5(){
  let e=useContext(C);
  return <><h2>Component 5</h2><p>Department: {e.dept}</p><p>Salary: {e.salary}</p></>;
}

export default App;
