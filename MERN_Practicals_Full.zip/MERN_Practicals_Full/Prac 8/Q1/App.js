import {useState,useEffect} from "react";

function App(){
  const [data,setData]=useState([]);

  useEffect(()=>{
    fetch("https://jsonplaceholder.typicode.com/posts")
    .then(r=>r.json())
    .then(d=>setData(d));
  },[]);

  return(
  <>
    <h1>API Data</h1>
    {data.map(x=><p>{x.title}</p>)}
  </>);
}

export default App;
