import {createContext,useContext} from "react";

const C=createContext();

function App(){
  return <C.Provider value={{name:"Rahul",dept:"IT",salary:50000}}>
    <Employee/>
  </C.Provider>;
}

function Employee(){
  let e=useContext(C);

  return <>
    <h2>Employee</h2>
    <p>Name: {e.name}</p>
    <p>Department: {e.dept}</p>
    <Salary/>
  </>;
}

function Salary(){
  let e=useContext(C);
  return <p>Salary: {e.salary}</p>;
}

export default App;
