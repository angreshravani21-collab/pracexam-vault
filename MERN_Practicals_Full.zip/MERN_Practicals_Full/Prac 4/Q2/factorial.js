const readline = require("readline");
const EventEmitter = require("events");

const e = new EventEmitter();
const r = readline.createInterface({input:process.stdin, output:process.stdout});

e.on("factorial", n => {
  let f = 1;
  for(let i=1;i<=n;i++) f *= i;
  console.log("Factorial of " + n + " is " + f);
  r.close();
});

r.question("Enter a number: ", n => e.emit("factorial", Number(n)));
