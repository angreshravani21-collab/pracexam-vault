const fs = require("fs");
const readline = require("readline");
const EventEmitter = require("events");

const e = new EventEmitter();
const r = readline.createInterface({input:process.stdin, output:process.stdout});

e.on("textReady", text => {
  console.log("Custom event Fired : Text is ready - " + text);
  fs.writeFile("text.txt", text, () => {
    console.log("Text has been saved to text.txt");
    r.close();
  });
});

r.question("Enter some text:", text => e.emit("textReady", text));
