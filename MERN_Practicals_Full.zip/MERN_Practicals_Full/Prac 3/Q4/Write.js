const fs = require("fs/promises");

async function work() {
  await fs.writeFile("example.txt", "Writing in a file");
  console.log(await fs.readFile("example.txt", "utf-8"));

  await fs.appendFile("example.txt", "\nData appended via Node.js");
  await fs.rename("example.txt", "new.txt");

  console.log(await fs.readFile("new.txt", "utf-8"));
  await fs.unlink("new.txt");
}

work();
