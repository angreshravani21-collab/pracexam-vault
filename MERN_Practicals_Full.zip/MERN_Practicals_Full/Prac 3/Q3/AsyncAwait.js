const fs = require("fs/promises");

async function readFile() {
  let data = await fs.readFile("example.txt", "utf-8");
  console.log(data);
}
readFile();
