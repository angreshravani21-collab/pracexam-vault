const fs = require("fs");

let data = fs.readFileSync("sample.txt", "utf-8");
console.log(data);
